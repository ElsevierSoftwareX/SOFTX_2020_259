
clear all
close all
clc

load('Datos_de_Colombia3')

figure(1)
subplot(1,3,1)
I = imread('Colombia/Colombia_map5.png') ;
image(I) ;
title('Propagacion del virus')
axis off
hold on
% set(gcf,'Position',[0,1000,1400,800])
% set(gca,'color',[153,204,255]/255);
% green = [0,153,0]/255 ;
% show_map(S_Amazonas,[],[],[],C,green)
% hold on
% show_map(S_Antioquia,[],[],[],C,green)
% show_map(S_Arauca,[],[],[],C,green)
% show_map(S_Atlantico,[],[],[],C,green)
% show_map(S_Bolivar,[],[],[],C,green)
% show_map(S_Boyaca,[],[],[],C,green)
% show_map(S_Caldas,[],[],[],C,green)
% show_map(S_Caqueta,[],[],[],C,green)
% show_map(S_Casanare,[],[],[],C,green)
% show_map(S_Cauca,[],[],[],C,green)
% show_map(S_Cesar,[],[],[],C,green)
% show_map(S_Choco,[],[],[],C,green)
% show_map(S_Cordoba,[],[],[],C,green)
% show_map(S_Cundinamarca,[],[],[],C,green)
% show_map(S_Guainia,[],[],[],C,green)
% show_map(S_Guaviare,[],[],[],C,green)
% show_map(S_Huila,[],[],[],C,green)
% show_map(S_Guajira,[],[],[],C,green)
% show_map(S_Magdalena,[],[],[],C,green)
% show_map(S_Meta,[],[],[],C,green)
% show_map(S_Narino,[],[],[],C,green)
% show_map(S_NorteSantander,[],[],[],C,green)
% show_map(S_Putumayo,[],[],[],C,green)
% show_map(S_Quindio,[],[],[],C,green)
% show_map(S_Risaralda,[],[],[],C,green)
% show_map(S_Sanandres,[],[],[],C,green)
% show_map(S_Santander,[],[],[],C,green)
% show_map(S_Sucre,[],[],[],C,green)
% show_map(S_Tolima,[],[],[],C,green)
% show_map(S_Valle,[],[],[],C,green)
% show_map(S_Vaupes,[],[],[],C,green)
% show_map(S_Vichada,[],[],[],C,green)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xpos = C(:,1) ; % position in x axis
ypos = C(:,2) ; % position in y axis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Age_mu = 31.3 ;
Age_sigma = 30 ;
Age = max(0,normrnd(Age_mu,Age_sigma,1,S_Vichada(end))) ;
age1 = find(Age<40) ;
age2 = find((Age>=40)&(Age<70)) ;
age3 = find(Age>=70) ;
% Parameters to tune
%p = [pv1,pv2,pm3,pr4,p5]
%pv1 (Virality) probability of getting infected if neighbor of a sick agent
%pv2 (Virality) probability that the virus covers long distances (airplane)
%pm3 (Mortality) probability of death (age-independent)
%pr4 (Recovery) probability of being recovered
%p5 (Again Sick) probability of being sick after having been recovered
p = [0.05,0.03,0.0001,0.0001,0.005,0.01,0.005] ;
paux = p(1) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I_Amazonas = [] ;
I_Antioquia = [3988;3989;3990] ;
I_Arauca = [] ;
I_Atlantico = [] ;
I_Bolivar = [5833;5834] ;
I_Boyaca = [] ;
I_Caldas = [6757;6758] ;
I_Caqueta = [] ;
I_Casanare = [] ;
I_Cauca = [10984;10985] ;
I_Cesar = [] ;
I_Choco = [] ;
I_Cordoba = [] ;
I_Cundinamarca = [14393;14392;14391;14380] ;
I_Guainia = [] ;
I_Guaviare = [] ;
I_Huila = [] ;
I_Guajira = [] ;
I_Magdalena = [] ;
I_Meta = [20683;20684] ;
I_Narino = [] ;
I_NorteSantander = [23030;23031] ;
I_Putumayo = [] ;
I_Quindio = [23940;23941] ;
I_Risaralda = [] ;
I_Sanandres = [] ;
I_Santander = [24427;24427] ;
I_Sucre = [] ;
I_Tolima = [25376;25377] ;
I_Valle = [25951;25960] ;
I_Vaupes = [] ;
I_Vichada = [] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
R_Amazonas = [] ;
R_Antioquia = [] ;
R_Arauca = [] ;
R_Atlantico = [] ;
R_Bolivar = [] ;
R_Boyaca = [] ;
R_Caldas = [] ;
R_Caqueta = [] ;
R_Casanare = [] ;
R_Cauca = [] ;
R_Cesar = [] ;
R_Choco = [] ;
R_Cordoba = [] ;
R_Cundinamarca = [] ;
R_Guainia = [] ;
R_Guaviare = [] ;
R_Huila = [] ;
R_Guajira = [] ;
R_Magdalena = [] ;
R_Meta = [] ;
R_Narino = [] ;
R_NorteSantander = [] ;
R_Putumayo = [] ;
R_Quindio = [] ;
R_Risaralda = [] ;
R_Sanandres = [] ;
R_Santander = [] ;
R_Sucre = [] ;
R_Tolima = [] ;
R_Valle = [] ;
R_Vaupes = [] ;
R_Vichada = [] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D_Amazonas = [] ;
D_Antioquia = [] ;
D_Arauca = [] ;
D_Atlantico = [] ;
D_Bolivar = [] ;
D_Boyaca = [] ;
D_Caldas = [] ;
D_Caqueta = [] ;
D_Casanare = [] ;
D_Cauca = [] ;
D_Cesar = [] ;
D_Choco = [] ;
D_Cordoba = [] ;
D_Cundinamarca = [] ;
D_Guainia = [] ;
D_Guaviare = [] ;
D_Huila = [] ;
D_Guajira = [] ;
D_Magdalena = [] ;
D_Meta = [] ;
D_Narino = [] ;
D_NorteSantander = [] ;
D_Putumayo = [] ;
D_Quindio = [] ;
D_Risaralda = [] ;
D_Sanandres = [] ;
D_Santander = [] ;
D_Sucre = [] ;
D_Tolima = [] ;
D_Valle = [] ;
D_Vaupes = [] ;
D_Vichada = [] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ite = 3650 ; % number of iterations
A = zeros(32,32) ;
%A = ones(32,32) - eye(32) ;
for i = 1 : 32
    for j = 1 : 32
        if ((i==14)||(j==14))&(i~=j)
            A(i,j) =  1;
        end
    end
end
A(2,22) = 1 ; A(22,2) = 1 ; A(2,27) = 1 ; A(27,2) = 1 ; A(2,13) = 1 ;
A(13,2) = 1 ; A(2,29) = 1 ; A(29,2) = 1 ; A(2,12) = 1 ; A(12,2) = 1 ;
A(2,7) = 1 ; A(7,2) = 1 ; A(22,27) = 1 ; A(27,22) = 1 ; A(5,11) = 1 ;
A(11,5) = 1 ;  A(5,22) = 1 ; A(22,5) = 1 ; A(30,7) = 1 ; A(7,30) = 1 ;
A(30,21) = 1 ; A(21,30) = 1 ; A(21,8) = 1 ; A(8,21) = 1 ; A(3,6) = 1 ; 
A(6,3) = 1 ; A(32,15) = 1 ; A(15,32) = 1 ; A(9,32) = 1 ; A(32,9) = 1 ;
A(1,23) = 1 ; A(23,1) = 1 ; A(18,19) = 1 ; A(19,18) = 1 ;
A(8,17) = 1 ; A(17,8) = 1 ; A(1,31) = 1 ; A(31,1) = 1 ;
A(3,32) = 1 ; A(32,3) = 1 ; A(3,9) = 1 ; A(9,3) = 1 ;
A(4,5) = 1 ; A(5,4) = 1 ; A(20,32) = 1 ; A(32,20) = 1 ;
A(11,18) = 1 ; A(18,11) = 1 ; A(15,16) = 1 ; A(16,15) = 1 ;

%%A = 0*A ;

[fc_Amazonas, fc_Antioquia, fc_Arauca, fc_Atlantico, fc_Bolivar,...
    fc_Boyaca, fc_Caldas, fc_Caqueta, fc_Casanare, fc_Cauca, fc_Cesar,...
    fc_Choco, fc_Cordoba, fc_Cundinamarca, fc_Guainia, fc_Guaviare,...
    fc_Huila, fc_Guajira, fc_Magdalena, fc_Meta, fc_Narino,...
    fc_NorteSantander, fc_Putumayo, fc_Quindio, fc_Risaralda,... 
    fc_Sanandres, fc_Santander, fc_Sucre, fc_Tolima, fc_Valle, fc_Vaupes,...
    fc_Vichada] = flight_connections_col(A,S_Amazonas, S_Antioquia, S_Arauca, S_Atlantico, S_Bolivar, S_Boyaca,...
    S_Caldas, S_Caqueta, S_Casanare, S_Cauca, S_Cesar, S_Choco,...
    S_Cordoba, S_Cundinamarca, S_Guainia, S_Guaviare, S_Huila, S_Guajira,...
    S_Magdalena, S_Meta, S_Narino, S_NorteSantander, S_Putumayo,...
    S_Quindio, S_Risaralda, S_Sanandres, S_Santander, S_Sucre, S_Tolima,...
    S_Valle, S_Vaupes, S_Vichada) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S = {S_Amazonas, S_Antioquia, S_Arauca, S_Atlantico, S_Bolivar, S_Boyaca,...
    S_Caldas, S_Caqueta, S_Casanare, S_Cauca, S_Cesar, S_Choco,...
    S_Cordoba, S_Cundinamarca, S_Guainia, S_Guaviare, S_Huila, S_Guajira,...
    S_Magdalena, S_Meta, S_Narino, S_NorteSantander, S_Putumayo,...
    S_Quindio, S_Risaralda, S_Sanandres, S_Santander, S_Sucre, S_Tolima,...
    S_Valle, S_Vaupes, S_Vichada} ;

% S1 = {S_Antioquia, S_Bolivar, S_Caldas,  S_Cauca, S_Cundinamarca,...  
%     S_Meta, S_NorteSantander, S_Quindio, S_Santander,... 
%     S_Tolima, S_Valle} ;

figure(1)
subplot(1,3,2)
axis off
set(gcf,'Position',[0,2000,1700,600]) ;
I = imread('Colombia/Colombia_map.png') ;
image(I)
hold on
graph_plot(A,C,S)
axis off

renamevariables

figure(1)
subplot(1,3,1)
hold on
green = [0,153,0]/255 ;
show_map([],I_1,[],[],C,green)
show_map([],I_2,[],[],C,green)
show_map([],I_3,[],[],C,green)
show_map([],I_4,[],[],C,green)
show_map([],I_5,[],[],C,green)
show_map([],I_6,[],[],C,green)
show_map([],I_1,[],[],C,green)
show_map([],I_7,[],[],C,green)
show_map([],I_8,[],[],C,green)
show_map([],I_9,[],[],C,green)
show_map([],I_10,[],[],C,green)
show_map([],I_11,[],[],C,green)
show_map([],I_12,[],[],C,green)
show_map([],I_13,[],[],C,green)
show_map([],I_14,[],[],C,green)
show_map([],I_15,[],[],C,green)
show_map([],I_16,[],[],C,green)
show_map([],I_17,[],[],C,green)
show_map([],I_18,[],[],C,green)
show_map([],I_19,[],[],C,green)
show_map([],I_20,[],[],C,green)
show_map([],I_21,[],[],C,green)
show_map([],I_22,[],[],C,green)
show_map([],I_23,[],[],C,green)
show_map([],I_24,[],[],C,green)
show_map([],I_25,[],[],C,green)
show_map([],I_26,[],[],C,green)
show_map([],I_27,[],[],C,green)
show_map([],I_28,[],[],C,green)
show_map([],I_29,[],[],C,green)
show_map([],I_30,[],[],C,green)
show_map([],I_31,[],[],C,green)
show_map([],I_32,[],[],C,green)

Infectados = zeros(1,ite) ;
Recuperados = zeros(1,ite) ;
Muertos = zeros(1,ite) ;

Inf = [] ;
Rec = [] ;
Mue = [] ;
Tot = [] ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
time = clock ;
year = num2str(time(1)) ;
month = num2str(time(2)) ;
day = num2str(time(3)) ;
hour = num2str(time(4)) ;
min = num2str(time(5)) ;
sec = num2str(time(6)) ;
%v = VideoWriter(['virus_',year,'_',month,'_',day,'_',hour,'_',min,'.avi']) ;
%open(v) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for t = 1:ite  
    
    
    InfCluster = {I_1;I_2;I_3;I_4;I_5;I_6;I_7;I_8;I_9;I_10;I_11;I_12;I_13;I_14;...
        I_15;I_16;I_17;I_18;I_19;I_20;I_21;I_22;I_23;I_24;I_25;I_26;...
        I_27;I_28;I_29;I_30;I_31;I_32} ;
    RecCluster = {R_1;R_2;R_3;R_4;R_5;R_6;R_7;R_8;R_9;R_10;R_11;R_12;R_13;R_14;...
        R_15;R_16;R_17;R_18;R_19;R_20;R_21;R_22;R_23;R_24;R_25;R_26;...
        R_27;R_28;R_29;R_30;R_31;R_32} ;
    MueCluster = {D_1;D_2;D_3;D_4;D_5;D_6;D_7;D_8;D_9;D_10;D_11;D_12;D_13;D_14;...
        D_15;D_16;D_17;D_18;D_19;D_20;D_21;D_22;D_23;D_24;D_25;D_26;...
        D_27;D_28;D_29;D_30;D_31;D_32} ;
    
    
    for k = 1 : 32
        Inf = union(Inf,InfCluster{k}) ;
        Rec = union(Rec,RecCluster{k}) ;
        Mue = union(Mue,MueCluster{k}) ;
        Tot = union(Tot,S{k}) ;
    end
    
%     for k = 1 : 11
%         Tot = union(Tot,S1{k}) ;
%     end
    
    Infectados(1,t) = length(Inf)*4 ;
    Recuperados(1,t) = length(Rec)*4 ;
    Muertos(1,t) = length(Mue)*4 ;
    time = 0.1*[1:t] ;
    
    
    p(1) = max(0, (paux - 0.2*(Infectados(1,t))/length(Tot)) ) ;
    p(2) = p(1)/2 ;
    pindex = p(1) ;
    
    figure(1)
    subplot(3,3,3)
    plot(time,Infectados(1,1:t),'color',[255/255,128/255,0/255],'linewidth',2)
    xlabel('Dias')
    ylabel('Numero de infectados')
    subplot(3,3,6)
    plot(time,Recuperados(1,1:t),'b','linewidth',2)
    xlabel('Dias')
    ylabel('Numero de recuperados')
    subplot(3,3,9)
    plot(time,Muertos(1,1:t),'r','linewidth',2)
    xlabel('Dias')
    ylabel('Numero de fallecidos')
    [S_dif_1,I_dif_1,R_dif_1,D_dif_1,S_1,I_1,R_1,D_1,FSA_1,Flag_1] = update(S_1,I_1,R_1,D_1,xpos,ypos,fc_1,p,Age) ;   
    [S_dif_2,I_dif_2,R_dif_2,D_dif_2,S_2,I_2,R_2,D_2,FSA_2,Flag_2] = update(S_2,I_2,R_2,D_2,xpos,ypos,fc_2,p,Age) ;   
    [S_dif_3,I_dif_3,R_dif_3,D_dif_3,S_3,I_3,R_3,D_3,FSA_3,Flag_3] = update(S_3,I_3,R_3,D_3,xpos,ypos,fc_3,p,Age) ;   
    [S_dif_4,I_dif_4,R_dif_4,D_dif_4,S_4,I_4,R_4,D_4,FSA_4,Flag_4] = update(S_4,I_4,R_4,D_4,xpos,ypos,fc_4,p,Age) ;   
    [S_dif_5,I_dif_5,R_dif_5,D_dif_5,S_5,I_5,R_5,D_5,FSA_5,Flag_5] = update(S_5,I_5,R_5,D_5,xpos,ypos,fc_5,p,Age) ;   
    [S_dif_6,I_dif_6,R_dif_6,D_dif_6,S_6,I_6,R_6,D_6,FSA_6,Flag_6] = update(S_6,I_6,R_6,D_6,xpos,ypos,fc_6,p,Age) ;   
    [S_dif_7,I_dif_7,R_dif_7,D_dif_7,S_7,I_7,R_7,D_7,FSA_7,Flag_7] = update(S_7,I_7,R_7,D_7,xpos,ypos,fc_7,p,Age) ;   
    [S_dif_8,I_dif_8,R_dif_8,D_dif_8,S_8,I_8,R_8,D_8,FSA_8,Flag_8] = update(S_8,I_8,R_8,D_8,xpos,ypos,fc_8,p,Age) ;   
    [S_dif_9,I_dif_9,R_dif_9,D_dif_9,S_9,I_9,R_9,D_9,FSA_9,Flag_9] = update(S_9,I_9,R_9,D_9,xpos,ypos,fc_9,p,Age) ;   
    [S_dif_10,I_dif_10,R_dif_10,D_dif_10,S_10,I_10,R_10,D_10,FSA_10,Flag_10] = update(S_10,I_10,R_10,D_10,xpos,ypos,fc_10,p,Age) ;   
    [S_dif_11,I_dif_11,R_dif_11,D_dif_11,S_11,I_11,R_11,D_11,FSA_11,Flag_11] = update(S_11,I_11,R_11,D_11,xpos,ypos,fc_11,p,Age) ;   
    [S_dif_12,I_dif_12,R_dif_12,D_dif_12,S_12,I_12,R_12,D_12,FSA_12,Flag_12] = update(S_12,I_12,R_12,D_12,xpos,ypos,fc_12,p,Age) ;   
    [S_dif_13,I_dif_13,R_dif_13,D_dif_13,S_13,I_13,R_13,D_13,FSA_13,Flag_13] = update(S_13,I_13,R_13,D_13,xpos,ypos,fc_13,p,Age) ;   
    [S_dif_14,I_dif_14,R_dif_14,D_dif_14,S_14,I_14,R_14,D_14,FSA_14,Flag_14] = update(S_14,I_14,R_14,D_14,xpos,ypos,fc_14,p,Age) ;   
    [S_dif_15,I_dif_15,R_dif_15,D_dif_15,S_15,I_15,R_15,D_15,FSA_15,Flag_15] = update(S_15,I_15,R_15,D_15,xpos,ypos,fc_15,p,Age) ;   
    [S_dif_16,I_dif_16,R_dif_16,D_dif_16,S_16,I_16,R_16,D_16,FSA_16,Flag_16] = update(S_16,I_16,R_16,D_16,xpos,ypos,fc_16,p,Age) ;   
    [S_dif_17,I_dif_17,R_dif_17,D_dif_17,S_17,I_17,R_17,D_17,FSA_17,Flag_17] = update(S_17,I_17,R_17,D_17,xpos,ypos,fc_17,p,Age) ;   
    [S_dif_18,I_dif_18,R_dif_18,D_dif_18,S_18,I_18,R_18,D_18,FSA_18,Flag_18] = update(S_18,I_18,R_18,D_18,xpos,ypos,fc_18,p,Age) ;   
    [S_dif_19,I_dif_19,R_dif_19,D_dif_19,S_19,I_19,R_19,D_19,FSA_19,Flag_19] = update(S_19,I_19,R_19,D_19,xpos,ypos,fc_19,p,Age) ;   
    [S_dif_20,I_dif_20,R_dif_20,D_dif_20,S_20,I_20,R_20,D_20,FSA_20,Flag_20] = update(S_20,I_20,R_20,D_20,xpos,ypos,fc_20,p,Age) ;   
    [S_dif_21,I_dif_21,R_dif_21,D_dif_21,S_21,I_21,R_21,D_21,FSA_21,Flag_21] = update(S_21,I_21,R_21,D_21,xpos,ypos,fc_21,p,Age) ;   
    [S_dif_22,I_dif_22,R_dif_22,D_dif_22,S_22,I_22,R_22,D_22,FSA_22,Flag_22] = update(S_22,I_22,R_22,D_22,xpos,ypos,fc_22,p,Age) ;   
    [S_dif_23,I_dif_23,R_dif_23,D_dif_23,S_23,I_23,R_23,D_23,FSA_23,Flag_23] = update(S_23,I_23,R_23,D_23,xpos,ypos,fc_23,p,Age) ;   
    [S_dif_24,I_dif_24,R_dif_24,D_dif_24,S_24,I_24,R_24,D_24,FSA_24,Flag_24] = update(S_24,I_24,R_24,D_24,xpos,ypos,fc_24,p,Age) ;   
    [S_dif_25,I_dif_25,R_dif_25,D_dif_25,S_25,I_25,R_25,D_25,FSA_25,Flag_25] = update(S_25,I_25,R_25,D_25,xpos,ypos,fc_25,p,Age) ;   
    [S_dif_26,I_dif_26,R_dif_26,D_dif_26,S_26,I_26,R_26,D_26,FSA_26,Flag_26] = update(S_26,I_26,R_26,D_26,xpos,ypos,fc_26,p,Age) ;   
    [S_dif_27,I_dif_27,R_dif_27,D_dif_27,S_27,I_27,R_27,D_27,FSA_27,Flag_27] = update(S_27,I_27,R_27,D_27,xpos,ypos,fc_27,p,Age) ;   
    [S_dif_28,I_dif_28,R_dif_28,D_dif_28,S_28,I_28,R_28,D_28,FSA_28,Flag_28] = update(S_28,I_28,R_28,D_28,xpos,ypos,fc_28,p,Age) ;   
    [S_dif_29,I_dif_29,R_dif_29,D_dif_29,S_29,I_29,R_29,D_29,FSA_29,Flag_29] = update(S_29,I_29,R_29,D_29,xpos,ypos,fc_29,p,Age) ;   
    [S_dif_30,I_dif_30,R_dif_30,D_dif_30,S_30,I_30,R_30,D_30,FSA_30,Flag_30] = update(S_30,I_30,R_30,D_30,xpos,ypos,fc_30,p,Age) ;   
    [S_dif_31,I_dif_31,R_dif_31,D_dif_31,S_31,I_31,R_31,D_31,FSA_31,Flag_31] = update(S_31,I_31,R_31,D_31,xpos,ypos,fc_31,p,Age) ;   
    [S_dif_32,I_dif_32,R_dif_32,D_dif_32,S_32,I_32,R_32,D_32,FSA_32,Flag_32] = update(S_32,I_32,R_32,D_32,xpos,ypos,fc_32,p,Age) ;   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    FSA = [FSA_1,FSA_2,FSA_3,FSA_4,FSA_5,FSA_6,FSA_7,FSA_8,FSA_9,FSA_10,...
        FSA_11,FSA_12,FSA_13,FSA_14,FSA_15,FSA_16,FSA_17,FSA_18,FSA_19,...
        FSA_20,FSA_21,FSA_22,FSA_23,FSA_24,FSA_25,FSA_26,FSA_27,FSA_28,...
        FSA_29,FSA_30,FSA_31,FSA_32] ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_1 = union(intersect(S_1,FSA),I_dif_1) ;
    I_1 = union(intersect(S_1,FSA),I_1) ;
    S_1 = setdiff(S_1,intersect(S_1,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_2 = union(intersect(S_2,FSA),I_dif_2) ;
    I_2 = union(intersect(S_2,FSA),I_2) ;
    S_2 = setdiff(S_2,intersect(S_2,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_3 = union(intersect(S_3,FSA),I_dif_3) ;
    I_3 = union(intersect(S_3,FSA),I_3) ;
    S_3 = setdiff(S_3,intersect(S_3,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_4 = union(intersect(S_4,FSA),I_dif_4) ;
    I_4 = union(intersect(S_4,FSA),I_4) ;
    S_4 = setdiff(S_4,intersect(S_4,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_5 = union(intersect(S_5,FSA),I_dif_5) ;
    I_5 = union(intersect(S_5,FSA),I_5) ;
    S_5 = setdiff(S_5,intersect(S_5,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_6 = union(intersect(S_6,FSA),I_dif_6) ;
    I_6 = union(intersect(S_6,FSA),I_6) ;
    S_6 = setdiff(S_6,intersect(S_6,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_7 = union(intersect(S_7,FSA),I_dif_7) ;
    I_7 = union(intersect(S_7,FSA),I_7) ;
    S_7 = setdiff(S_7,intersect(S_7,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_8 = union(intersect(S_8,FSA),I_dif_8) ;
    I_8 = union(intersect(S_8,FSA),I_8) ;
    S_8 = setdiff(S_8,intersect(S_8,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_9 = union(intersect(S_9,FSA),I_dif_9) ;
    I_9 = union(intersect(S_9,FSA),I_9) ;
    S_9 = setdiff(S_9,intersect(S_9,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_10 = union(intersect(S_10,FSA),I_dif_10) ;
    I_10 = union(intersect(S_10,FSA),I_10) ;
    S_10 = setdiff(S_10,intersect(S_10,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_11 = union(intersect(S_11,FSA),I_dif_11) ;
    I_11 = union(intersect(S_11,FSA),I_11) ;
    S_11 = setdiff(S_11,intersect(S_11,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_12 = union(intersect(S_12,FSA),I_dif_12) ;
    I_12 = union(intersect(S_12,FSA),I_12) ;
    S_12 = setdiff(S_12,intersect(S_12,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_13 = union(intersect(S_13,FSA),I_dif_13) ;
    I_13 = union(intersect(S_13,FSA),I_13) ;
    S_13 = setdiff(S_13,intersect(S_13,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_14 = union(intersect(S_14,FSA),I_dif_14) ;
    I_14 = union(intersect(S_14,FSA),I_14) ;
    S_14 = setdiff(S_14,intersect(S_14,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_15 = union(intersect(S_15,FSA),I_dif_15) ;
    I_15 = union(intersect(S_15,FSA),I_15) ;
    S_15 = setdiff(S_15,intersect(S_15,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_16 = union(intersect(S_16,FSA),I_dif_16) ;
    I_16 = union(intersect(S_16,FSA),I_16) ;
    S_16 = setdiff(S_16,intersect(S_16,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_17 = union(intersect(S_17,FSA),I_dif_17) ;
    I_17 = union(intersect(S_17,FSA),I_17) ;
    S_17 = setdiff(S_17,intersect(S_17,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_18 = union(intersect(S_18,FSA),I_dif_18) ;
    I_18 = union(intersect(S_18,FSA),I_18) ;
    S_18 = setdiff(S_18,intersect(S_18,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_19 = union(intersect(S_19,FSA),I_dif_19) ;
    I_19 = union(intersect(S_19,FSA),I_19) ;
    S_19 = setdiff(S_19,intersect(S_19,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_20 = union(intersect(S_20,FSA),I_dif_20) ;
    I_20 = union(intersect(S_20,FSA),I_20) ;
    S_20 = setdiff(S_20,intersect(S_20,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_21 = union(intersect(S_21,FSA),I_dif_21) ;
    I_21 = union(intersect(S_21,FSA),I_21) ;
    S_21 = setdiff(S_21,intersect(S_21,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_22 = union(intersect(S_22,FSA),I_dif_22) ;
    I_22 = union(intersect(S_22,FSA),I_22) ;
    S_22 = setdiff(S_22,intersect(S_22,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_23 = union(intersect(S_23,FSA),I_dif_23) ;
    I_23 = union(intersect(S_23,FSA),I_23) ;
    S_23 = setdiff(S_23,intersect(S_23,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_24 = union(intersect(S_24,FSA),I_dif_24) ;
    I_24 = union(intersect(S_24,FSA),I_24) ;
    S_24 = setdiff(S_24,intersect(S_24,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_25 = union(intersect(S_25,FSA),I_dif_25) ;
    I_25 = union(intersect(S_25,FSA),I_25) ;
    S_25 = setdiff(S_25,intersect(S_25,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_26 = union(intersect(S_26,FSA),I_dif_26) ;
    I_26 = union(intersect(S_26,FSA),I_26) ;
    S_26 = setdiff(S_26,intersect(S_26,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_27 = union(intersect(S_27,FSA),I_dif_27) ;
    I_27 = union(intersect(S_27,FSA),I_27) ;
    S_27 = setdiff(S_27,intersect(S_27,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_28 = union(intersect(S_28,FSA),I_dif_28) ;
    I_28 = union(intersect(S_28,FSA),I_28) ;
    S_28 = setdiff(S_28,intersect(S_28,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_29 = union(intersect(S_29,FSA),I_dif_29) ;
    I_29 = union(intersect(S_29,FSA),I_29) ;
    S_29 = setdiff(S_29,intersect(S_29,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_30 = union(intersect(S_30,FSA),I_dif_30) ;
    I_30 = union(intersect(S_30,FSA),I_30) ;
    S_30 = setdiff(S_30,intersect(S_30,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_31 = union(intersect(S_31,FSA),I_dif_31) ;
    I_31 = union(intersect(S_31,FSA),I_31) ;
    S_31 = setdiff(S_31,intersect(S_31,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I_dif_32 = union(intersect(S_32,FSA),I_dif_32) ;
    I_32 = union(intersect(S_32,FSA),I_32) ;
    S_32 = setdiff(S_32,intersect(S_32,FSA)) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(1)
    subplot(1,3,1)
    hold on
    set(gcf,'Position',[0,2000,1700,600]) ;
    set(gca,'color',[153,204,255]/255);
    green = [0,153,0]/255 ;
    show_map([],I_dif_1,R_dif_1,D_dif_1,C,green)
    hold on
    show_map([],I_dif_2,R_dif_2,D_dif_2,C,green)
    show_map([],I_dif_3,R_dif_3,D_dif_3,C,green)
    show_map([],I_dif_4,R_dif_4,D_dif_4,C,green)
    show_map([],I_dif_5,R_dif_5,D_dif_5,C,green)
    show_map([],I_dif_6,R_dif_6,D_dif_6,C,green)
    show_map([],I_dif_7,R_dif_7,D_dif_7,C,green)
    show_map([],I_dif_8,R_dif_8,D_dif_8,C,green)
    show_map([],I_dif_9,R_dif_9,D_dif_9,C,green)
    show_map([],I_dif_10,R_dif_10,D_dif_10,C,green)
    show_map([],I_dif_11,R_dif_11,D_dif_11,C,green)
    show_map([],I_dif_12,R_dif_12,D_dif_12,C,green)
    show_map([],I_dif_13,R_dif_13,D_dif_13,C,green)
    show_map([],I_dif_14,R_dif_14,D_dif_14,C,green)
    show_map([],I_dif_15,R_dif_15,D_dif_15,C,green)
    show_map([],I_dif_16,R_dif_16,D_dif_16,C,green)
    show_map([],I_dif_17,R_dif_17,D_dif_17,C,green)
    show_map([],I_dif_18,R_dif_18,D_dif_18,C,green)
    show_map([],I_dif_19,R_dif_19,D_dif_19,C,green)
    show_map([],I_dif_20,R_dif_20,D_dif_20,C,green)
    show_map([],I_dif_21,R_dif_21,D_dif_21,C,green)
    show_map([],I_dif_22,R_dif_22,D_dif_22,C,green)
    show_map([],I_dif_23,R_dif_23,D_dif_23,C,green)
    show_map([],I_dif_24,R_dif_24,D_dif_24,C,green)
    show_map([],I_dif_25,R_dif_25,D_dif_25,C,green)
    show_map([],I_dif_26,R_dif_26,D_dif_26,C,green)
    show_map([],I_dif_27,R_dif_27,D_dif_27,C,green)
    show_map([],I_dif_28,R_dif_28,D_dif_28,C,green)
    show_map([],I_dif_29,R_dif_29,D_dif_29,C,green)
    show_map([],I_dif_30,R_dif_30,D_dif_30,C,green)
    show_map([],I_dif_31,R_dif_31,D_dif_31,C,green)
    show_map([],I_dif_32,R_dif_32,D_dif_32,C,green)    
    %F = getframe(gcf) ;
    %writeVideo(v,F) ;
end

%close(v) ;