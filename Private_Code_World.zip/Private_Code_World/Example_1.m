%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Authors: J. Barreiro-Gomez, S. E. Choutri, and H. Tembine 
%%%% Learning & Game Theory Laboratory (L&G Lab)
%%%% Center on Stability, Instability and Turbulence (SITE)
%%%% NYUAD 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%This example presents the construction of the continents with
%%%% different resolutions and computation of X-Y coordinates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I = imread('continents.png') ; % The reference image is imported
resolution_grid = 8 ; % This defines the resolution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Datos_NorthAmerica,Datos_SouthAmerica,Datos_Africa,Datos_Europe,Datos_Asia,Datos_Oceania]... 
    = construct_continents(I,resolution_grid) ; % Data per continent are generated
%%%% Datos are organized as follows: (1) Number of nodes in the continent,
%%%% (2) Coordinates vector, and (3) Map of the continent
C = [Datos_NorthAmerica{2};
    Datos_SouthAmerica{2};
    Datos_Africa{2};
    Datos_Europe{2};
    Datos_Asia{2};
    Datos_Oceania{2}] ; % This is the vector of coordinates for the entire world
xpos = C(:,1) ; % Position in x axis
ypos = C(:,2) ; % Position in y axis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% We plot the continents to show how the map was constructed.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(2,3,1)
image(Datos_NorthAmerica{3})
colormap(gray)
title('North America')
%
subplot(2,3,2)
image(Datos_SouthAmerica{3})
colormap(gray)
title('South America')
%
subplot(2,3,3)
image(Datos_Africa{3})
colormap(gray)
title('Africa')
%
subplot(2,3,4)
image(Datos_Europe{3})
colormap(gray)
title('Europe')
%
subplot(2,3,5)
image(Datos_Asia{3})
colormap(gray)
title('Asia')
%
subplot(2,3,6)
image(Datos_Oceania{3})
colormap(gray)
title('Australia')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
image(Datos_NorthAmerica{3}+Datos_SouthAmerica{3}+Datos_Africa{3}+Datos_Europe{3}+Datos_Asia{3}+Datos_Oceania{3})
colormap(gray)
title('World')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
