%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Authors: J. Barreiro-Gomez, S. E. Choutri, and H. Tembine 
%%%% Learning & Game Theory Laboratory (L&G Lab)
%%%% Center on Stability, Instability and Turbulence (SITE)
%%%% NYUAD 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% In this code the parameters are introduced for the whole simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I = imread('continents.png') ; % The reference image is imported
resolution_grid = 8 ; % This defines the resolution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Datos_NorthAmerica,Datos_SouthAmerica,Datos_Africa,Datos_Europe,Datos_Asia,Datos_Oceania]... 
    = construct_continents(I,resolution_grid) ; % Data per continent are generated
%%%% Datos are organized as follows: (1) Number of nodes in the continent,
%%%% (2) Coordinates vector, and (3) Map of the continent
C = [Datos_NorthAmerica{2};
    Datos_SouthAmerica{2};
    Datos_Africa{2};
    Datos_Europe{2};
    Datos_Asia{2};
    Datos_Oceania{2}] ; % This is the vector of coordinates for the entire world
xpos = C(:,1) ; % Position in x axis
ypos = C(:,2) ; % Position in y axis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_NorthAmerica = 1:Datos_NorthAmerica{1} ; 
S_SouthAmerica = Datos_NorthAmerica{1}+(1:Datos_SouthAmerica{1}) ; 
S_Africa = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1})+(1:Datos_Africa{1}) ; 
S_Europe = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1})+(1:Datos_Europe{1}) ; 
S_Asia = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1})+(1:Datos_Asia{1}) ; 
S_Oceania = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1}+Datos_Asia{1})+(1:Datos_Oceania{1}) ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Here we use an arbitrary numerical example to explain the use of the
%%%% tool. Nevertheless, real mean and variance age for the different
%%%% regions should be introduced
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
age_mu_NA = 40; % mean age in NorthAmerica
age_sigma_NA = 20; % variance age in NorthAmerica
age_NA = max(0,normrnd(age_mu_NA,age_sigma_NA,1,Datos_NorthAmerica{1})) ; % vector age in NorthAmerica
%
age_mu_SA = 38; % mean age in SouthAmerica
age_sigma_SA = 30; % variance age in SouthAmerica
age_SA = max(0,normrnd(age_mu_SA,age_sigma_SA,1,Datos_SouthAmerica{1})) ; % vector age in SouthAmerica
%
age_mu_A = 35; % mean age in Africa
age_sigma_A = 22; % variance age in Africa
age_A = max(0,normrnd(age_mu_A,age_sigma_A,1,Datos_Africa{1})) ; % vector age in Africa
%
age_mu_E = 29; % mean age in Europe
age_sigma_E = 30; % variance age in Europe
age_E = max(0,normrnd(age_mu_E,age_sigma_E,1,Datos_Europe{1})) ; % vector age in Europe
%
age_mu_As = 42; % mean age in Asia
age_sigma_As = 30; % variance age in Asia
age_As = max(0,normrnd(age_mu_As,age_sigma_As,1,Datos_Asia{1})) ; % vector age in Asia
%
age_mu_O = 33; % mean age in Australia
age_sigma_O = 23; % variance age in Australia
age_O = max(0,normrnd(age_mu_O,age_sigma_O,1,Datos_Oceania{1})) ; % vector age in Australia
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Age = [age_NA,age_SA,age_A,age_E,age_As,age_O] ;
age1 = find(Age<40) ;
age2 = find((Age>=40)&(Age<70)) ;
age3 = find(Age>=70) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameters to tune
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%p = [pv1,pv2,pm31,pm32,pm33,pr4,p5]
%pv1 (Virality) probability of getting infected if neighbor of a sick agent
%pv2 (Virality) probability that the virus covers long distances (airplane)
%pm31 (Mortality) probability of death (age-dependent) [0-39]
%pm32 (Mortality) probability of death (age-dependent) [40-69]
%pm33 (Mortality) probability of death (age-dependent) [70+]
%pr4 (Recovery) probability of being recovered
%ps5 (Again Sick) probability of being sick after having been recovered
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_NorthAmerica = 1:Datos_NorthAmerica{1} ; 
I_NorthAmerica = [] ; 
R_NorthAmerica = [] ; 
D_NorthAmerica = [] ;
p_NorthAmerica = [0.3,0.02,0.01,0.08,0.08,0.1,0.01] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_SouthAmerica = Datos_NorthAmerica{1}+(1:Datos_SouthAmerica{1}) ; 
I_SouthAmerica = [] ; 
R_SouthAmerica = [] ; 
D_SouthAmerica = [] ; 
p_SouthAmerica = [0.3,0.02,0.01,0.08,0.08,0.1,0.01] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_Africa = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1})+(1:Datos_Africa{1}) ; 
I_Africa = [] ; 
R_Africa = [] ; 
D_Africa = [] ; 
p_Africa = [0.05,0.02,0.01,0.08,0.08,0.1,0.01] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_Europe = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1})+(1:Datos_Europe{1}) ; 
I_Europe = [] ;
R_Europe = [] ; 
D_Europe = [] ; 
p_Europe = [1,0.2,0.15,0.02,0.02,0.1,0.03] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_Asia = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1})+(1:Datos_Asia{1}) ; 
I_Asia = 3442 ; 
R_Asia = [] ; 
D_Asia = [] ; 
p_Asia = [1,0.2,0.15,0.02,0.02,0.1,0.03] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_Oceania = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1}+Datos_Asia{1})+(1:Datos_Oceania{1}) ; 
I_Oceania = [] ;
R_Oceania = [] ; 
D_Oceania = [] ; 
p_Oceania = [0.1,0.02,0.005,0.08,0.08,0.1,0.01] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ite = 1000 ; % number of iterations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Here user decides the posible flight connecvtions%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% North_America / South America / Africa / Europe / Asia / Oceania
A = [0 1 0 1 1 1 ;
     1 0 0 1 0 0 ;
     0 0 0 1 0 0 ;
     1 1 1 0 1 1 ;
     1 0 0 1 0 1 ;
     1 0 0 1 1 0] ; % adjacency matrix defining possible flight connections
[fc_NorthAmerica,fc_SouthAmerica,fc_Africa,fc_Europe,fc_Asia,fc_Oceania] = flight_connections(A,S_NorthAmerica,S_SouthAmerica,S_Africa,S_Europe,S_Asia,S_Oceania) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
