%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Authors: J. Barreiro-Gomez, S. E. Choutri, and H. Tembine 
%%%% Learning & Game Theory Laboratory (L&G Lab)
%%%% Center on Stability, Instability and Turbulence (SITE)
%%%% NYUAD 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This generates the whole simulation of the virus propagation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Parameters are uploaded
parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
subplot(2,2,1)
set(gcf,'Position',[0,1000,1400,800])
set(gca,'color',[153,204,255]/255);
green = [0,153,0]/255 ;
show_map(S_NorthAmerica,I_NorthAmerica,R_NorthAmerica,D_NorthAmerica,C,green)
hold on
show_map(S_SouthAmerica,I_SouthAmerica,R_SouthAmerica,D_SouthAmerica,C,green)
show_map(S_Africa,I_Africa,R_Africa,D_Africa,C,green)
show_map(S_Europe,I_Europe,R_Europe,D_Europe,C,green)
show_map(S_Asia,I_Asia,R_Asia,D_Asia,C,green)
show_map(S_Oceania,I_Oceania,R_Oceania,D_Oceania,C,green)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for t = 1:ite
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(1)
    subplot(2,2,2)
    graph_plot(A)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    S = S_NorthAmerica ;
    I = I_NorthAmerica ;
    R = R_NorthAmerica ;
    D = D_NorthAmerica ;
    p = p_NorthAmerica ;
    flight_connections = fc_NorthAmerica ;
    [S_dif_NA,I_dif_NA,R_dif_NA,D_dif_NA,S_NorthAmerica,I_NorthAmerica,R_NorthAmerica,D_NorthAmerica,FSA_NA,Flag_NA] = update(S,I,R,D,xpos,ypos,flight_connections,p,Age) ;
    %
    S = S_SouthAmerica ;
    I = I_SouthAmerica ;
    R = R_SouthAmerica ;
    D = D_SouthAmerica ;
    p = p_SouthAmerica ;
    flight_connections = fc_SouthAmerica ;
    [S_dif_SA,I_dif_SA,R_dif_SA,D_dif_SA,S_SouthAmerica,I_SouthAmerica,R_SouthAmerica,D_SouthAmerica,FSA_SA,Flag_SA] = update(S,I,R,D,xpos,ypos,flight_connections,p,Age) ;
    %
    S = S_Africa ;
    I = I_Africa ;
    R = R_Africa ;
    D = D_Africa ;
    p = p_Africa ;
    flight_connections = fc_Africa ;
    [S_dif_A,I_dif_A,R_dif_A,D_dif_A,S_Africa,I_Africa,R_Africa,D_Africa,FSA_A,Flag_A] = update(S,I,R,D,xpos,ypos,flight_connections,p,Age) ;
    %
    S = S_Europe ;
    I = I_Europe ;
    R = R_Europe ;
    D = D_Europe ;
    p = p_Europe ;
    flight_connections = fc_Europe ;
    [S_dif_E,I_dif_E,R_dif_E,D_dif_E,S_Europe,I_Europe,R_Europe,D_Europe,FSA_E,Flag_E] = update(S,I,R,D,xpos,ypos,flight_connections,p,Age) ;
    %
    S = S_Asia ;
    I = I_Asia ;
    R = R_Asia ;
    D = D_Asia ;
    p = p_Asia ;
    flight_connections = fc_Asia ;
    [S_dif_As,I_dif_As,R_dif_As,D_dif_As,S_Asia,I_Asia,R_Asia,D_Asia,FSA_As,Flag_As] = update(S,I,R,D,xpos,ypos,flight_connections,p,Age) ;
    %
    S = S_Oceania ;
    I = I_Oceania ;
    R = R_Oceania ;
    D = D_Oceania ;
    p = p_Oceania ;
    flight_connections = fc_Oceania ;
    [S_dif_O,I_dif_O,R_dif_O,D_dif_O,S_Oceania,I_Oceania,R_Oceania,D_Oceania,FSA_O,Flag_O] = update(S,I,R,D,xpos,ypos,flight_connections,p,Age) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    FSA = [FSA_NA,FSA_SA,FSA_A,FSA_E,FSA_As,FSA_O] ;
    %
    I_dif = I_dif_NA ;
    S = S_NorthAmerica ;
    I = I_NorthAmerica ;
    [I_dif_NA,I_NorthAmerica] = long_dist_update(FSA,I_dif,S,I) ;
    %
    I_dif = I_dif_SA ;
    S = S_SouthAmerica ;
    I = I_SouthAmerica ;
    [I_dif_SA,I_SouthAmerica] = long_dist_update(FSA,I_dif,S,I) ;
    %
    I_dif = I_dif_A ;
    S = S_Africa ;
    I = I_Africa ;
    [I_dif_A,I_Africa] = long_dist_update(FSA,I_dif,S,I) ;
    %
    I_dif = I_dif_E ;
    S = S_Europe ;
    I = I_Europe ;
    [I_dif_E,I_Europe] = long_dist_update(FSA,I_dif,S,I) ;
    %
    I_dif = I_dif_As ;
    S = S_Asia ;
    I = I_Asia ;
    [I_dif_As,I_Asia] = long_dist_update(FSA,I_dif,S,I) ;
    %
    I_dif = I_dif_O ;
    S = S_Oceania ;
    I = I_Oceania ;
    [I_dif_O,I_Oceania] = long_dist_update(FSA,I_dif,S,I) ;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(1)
    subplot(2,2,1)
    set(gcf,'Position',[0,1000,1400,800])
    set(gca,'color',[153,204,255]/255);
    show_map([],I_dif_NA,R_dif_NA,D_dif_NA,C,green)
    hold on
    show_map([],I_dif_SA,R_dif_SA,D_dif_SA,C,green)
    show_map([],I_dif_A,R_dif_A,D_dif_A,C,green)
    show_map([],I_dif_E,R_dif_E,D_dif_E,C,green)
    show_map([],I_dif_As,R_dif_As,D_dif_As,C,green)
    show_map([],I_dif_O,R_dif_O,D_dif_O,C,green)
    title('Code Authors: Barreiro-Gomez, Choutri and Tembine (L&G Lab - SITE)')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    bar_plots
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for slow = 1 : 3
        F = getframe(gcf) ;
        writeVideo(v,F) ;
    end
end