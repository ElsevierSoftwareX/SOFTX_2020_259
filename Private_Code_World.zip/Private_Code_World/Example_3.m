%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Authors: J. Barreiro-Gomez, S. E. Choutri, and H. Tembine 
%%%% Learning & Game Theory Laboratory (L&G Lab)
%%%% Center on Stability, Instability and Turbulence (SITE)
%%%% NYUAD 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This example presents the generation of the age distribution for all
%%%% the regions in the map
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I = imread('continents.png') ; % The reference image is imported
resolution_grid = 8 ; % This defines the resolution
[Datos_NorthAmerica,Datos_SouthAmerica,Datos_Africa,Datos_Europe,Datos_Asia,Datos_Oceania]... 
    = construct_continents(I,resolution_grid) ; % Data per continent are generated
%%%% Datos are organized as follows: (1) Number of nodes in the continent,
%%%% (2) Coordinates vector, and (3) Map of the continent
C = [Datos_NorthAmerica{2};
    Datos_SouthAmerica{2};
    Datos_Africa{2};
    Datos_Europe{2};
    Datos_Asia{2};
    Datos_Oceania{2}] ; % This is the vector of coordinates for the entire world
xpos = C(:,1) ; % Position in x axis
ypos = C(:,2) ; % Position in y axis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_NorthAmerica = 1:Datos_NorthAmerica{1} ; 
S_SouthAmerica = Datos_NorthAmerica{1}+(1:Datos_SouthAmerica{1}) ; 
S_Africa = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1})+(1:Datos_Africa{1}) ; 
S_Europe = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1})+(1:Datos_Europe{1}) ; 
S_Asia = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1})+(1:Datos_Asia{1}) ; 
S_Oceania = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1}+Datos_Asia{1})+(1:Datos_Oceania{1}) ; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Here we use an arbitrary numerical example to explain the use of the
%%%% tool. Nevertheless, real mean and variance age for the different
%%%% regions should be introduced
age_mu_NA = 40; % mean age in NorthAmerica
age_sigma_NA = 20; % variance age in NorthAmerica
age_NA = max(0,normrnd(age_mu_NA,age_sigma_NA,1,Datos_NorthAmerica{1})) ; % vector age in NorthAmerica
%
age_mu_SA = 38; % mean age in SouthAmerica
age_sigma_SA = 30; % variance age in SouthAmerica
age_SA = max(0,normrnd(age_mu_SA,age_sigma_SA,1,Datos_SouthAmerica{1})) ; % vector age in SouthAmerica
%
age_mu_A = 35; % mean age in Africa
age_sigma_A = 22; % variance age in Africa
age_A = max(0,normrnd(age_mu_A,age_sigma_A,1,Datos_Africa{1})) ; % vector age in Africa
%
age_mu_E = 29; % mean age in Europe
age_sigma_E = 30; % variance age in Europe
age_E = max(0,normrnd(age_mu_E,age_sigma_E,1,Datos_Europe{1})) ; % vector age in Europe
%
age_mu_As = 42; % mean age in Asia
age_sigma_As = 30; % variance age in Asia
age_As = max(0,normrnd(age_mu_As,age_sigma_As,1,Datos_Asia{1})) ; % vector age in Asia
%
age_mu_O = 33; % mean age in Australia
age_sigma_O = 23; % variance age in Australia
age_O = max(0,normrnd(age_mu_O,age_sigma_O,1,Datos_Oceania{1})) ; % vector age in Australia
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Histrograms corresponding to the ages per region
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(2,3,1)
histogram(age_NA)
title('North America')
subplot(2,3,2)
histogram(age_SA)
title('South America')
subplot(2,3,3)
histogram(age_A)
title('Africa')
subplot(2,3,4)
histogram(age_E)
title('Europe')
subplot(2,3,5)
histogram(age_As)
title('Asia')
subplot(2,3,6)
histogram(age_O)
title('Australia')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Ages in the map
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Age = [age_NA,age_SA,age_A,age_E,age_As,age_O] ;
age1 = find(Age<40) ;
age2 = find((Age>=40)&(Age<70)) ;
age3 = find(Age>=70) ;
figure
show_age(C,age1,age2,age3) 
title('Ages : 0-39 = Red, 40-69 = Blue, 70+ = Green')
