%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Authors: J. Barreiro-Gomez, S. E. Choutri, and H. Tembine 
%%%% Learning & Game Theory Laboratory (L&G Lab)
%%%% Center on Stability, Instability and Turbulence (SITE)
%%%% NYUAD 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% This example presents the construction of the following sets per
%%%% continent:
%%%% S = susceptible
%%%% I = infected
%%%% R = recovered
%%%% D = dead
%%%% And how to plot the sets with different colors in the map
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I = imread('continents.png') ; % The reference image is imported
resolution_grid = 8 ; % This defines the resolution
[Datos_NorthAmerica,Datos_SouthAmerica,Datos_Africa,Datos_Europe,Datos_Asia,Datos_Oceania]... 
    = construct_continents(I,resolution_grid) ; % Data per continent are generated
%%%% Datos are organized as follows: (1) Number of nodes in the continent,
%%%% (2) Coordinates vector, and (3) Map of the continent
C = [Datos_NorthAmerica{2};
    Datos_SouthAmerica{2};
    Datos_Africa{2};
    Datos_Europe{2};
    Datos_Asia{2};
    Datos_Oceania{2}] ; % This is the vector of coordinates for the entire world
xpos = C(:,1) ; % Position in x axis
ypos = C(:,2) ; % Position in y axis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_NorthAmerica = 1:Datos_NorthAmerica{1} ; 
S_SouthAmerica = Datos_NorthAmerica{1}+(1:Datos_SouthAmerica{1}) ; 
S_Africa = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1})+(1:Datos_Africa{1}) ; 
S_Europe = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1})+(1:Datos_Europe{1}) ; 
S_Asia = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1})+(1:Datos_Asia{1}) ; 
S_Oceania = (Datos_NorthAmerica{1}+Datos_SouthAmerica{1}+Datos_Africa{1}+Datos_Europe{1}+Datos_Asia{1})+(1:Datos_Oceania{1}) ; 
figure
show_map(S_NorthAmerica,[],[],[],C,[1,0,0])
hold on
show_map(S_SouthAmerica,[],[],[],C,[0,1,0])
show_map(S_Africa,[],[],[],C,[0,0,1])
show_map(S_Europe,[],[],[],C,[0,1,1])
show_map(S_Asia,[],[],[],C,[1,1,0])
show_map(S_Oceania,[],[],[],C,[1,0,1])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
agent_i = 350 ;
radius_i = 20 ;
agent_d = 520 ;
radius_d = 10 ;
S_NorthAmerica = 1:Datos_NorthAmerica{1} ;
I_NorthAmerica = neighbor(agent_i,radius_i,xpos,ypos) ; 
R_NorthAmerica = 500 ; 
D_NorthAmerica = neighbor(agent_d,radius_d,xpos,ypos) ;  
color = [0,0,1] ;
figure
show_map(S_NorthAmerica,I_NorthAmerica,R_NorthAmerica,D_NorthAmerica,C,color)
set(gca,'color',[0,0,0]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%